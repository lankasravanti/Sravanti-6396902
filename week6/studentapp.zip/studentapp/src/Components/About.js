import React from 'react';

function About() {
  return (
    <div>
      <h2>Welcome to the About page of Student Management Portal</h2>
    </div>
  );
}

export default About;
