import React, { useState } from 'react';

function CurrencyConvertor() {
  const [rupees, setRupees] = useState('');
  const [euros, setEuros] = useState('');

  const handleSubmit = () => {
    const conversionRate = 0.011; // 1 INR ≈ 0.011 Euro
    const converted = (parseFloat(rupees) * conversionRate).toFixed(2);
    setEuros(converted);
  };

  return (
    <div>
      <h2>Currency Convertor (INR → EUR)</h2>
      <input
        type="number"
        value={rupees}
        onChange={(e) => setRupees(e.target.value)}
        placeholder="Enter INR"
      />
      <button onClick={handleSubmit}>Convert</button>
      {euros && <p>Equivalent in Euros: €{euros}</p>}
    </div>
  );
}

export default CurrencyConvertor;
