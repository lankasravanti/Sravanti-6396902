import React, { useState } from 'react';
import './App.css';
import CurrencyConvertor from './CurrencyConvertor';

function App() {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(count + 1);
    sayHello();
    showMessage();
  };

  const decrement = () => {
    setCount(count - 1);
  };

  const sayHello = () => {
    console.log("Hello!");
  };

  const showMessage = () => {
    console.log("Static Message: React Event Handling Example");
  };

  const sayWelcome = (msg) => {
    alert(msg);
  };

  const handlePress = (e) => {
    alert("I was clicked!");
    console.log("Synthetic Event:", e);
  };

  return (
    <div className="App">
      <h1>Event Handling in React</h1>
      <h2>Counter: {count}</h2>
      <button onClick={increment}>Increment</button>
      <button onClick={decrement}>Decrement</button>

      <br /><br />

      <button onClick={() => sayWelcome("Welcome to React Events!")}>Say Welcome</button>

      <br /><br />

      <button onClick={handlePress}>Synthetic Event - OnPress</button>

      <br /><br />

      <CurrencyConvertor />
    </div>
  );
}

export default App;
