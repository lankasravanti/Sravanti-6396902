import React from 'react';

function GuestPage() {
  return (
    <div>
      <h2>Welcome Guest!</h2>
      <p>Flight Details:</p>
      <ul>
        <li>Flight: AI202 | From: Delhi | To: Mumbai | Time: 6:00 AM</li>
        <li>Flight: AI305 | From: Bangalore | To: Chennai | Time: 8:30 AM</li>
        <li>Flight: AI450 | From: Hyderabad | To: Pune | Time: 3:45 PM</li>
      </ul>
    </div>
  );
}

export default GuestPage;
