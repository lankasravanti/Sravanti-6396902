import React from 'react';

function UserPage() {
  return (
    <div>
      <h2>Welcome Back, User!</h2>
      <p>You can now book your tickets below:</p>
      <button>Book AI202</button>
      <button>Book AI305</button>
      <button>Book AI450</button>
    </div>
  );
}

export default UserPage;
