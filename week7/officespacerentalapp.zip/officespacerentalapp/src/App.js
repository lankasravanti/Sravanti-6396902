import React from 'react';
import './App.css';

function App() {
  const heading = "Office Space Rental";

  const officeImage = "https://via.placeholder.com/400x200?text=Office+Image";

  const offices = [
    { name: "Tech Hub", rent: 75000, address: "MG Road, Bengaluru" },
    { name: "Startup Nest", rent: 58000, address: "HITEC City, Hyderabad" },
    { name: "Corporate Suites", rent: 90000, address: "Gurgaon Sector 44" },
    { name: "Budget Biz", rent: 40000, address: "Salt Lake, Kolkata" }
  ];

  const rentStyle = (amount) => ({
    color: amount < 60000 ? 'red' : 'green'
  });

  return (
    <div className="App">
      <h1>{heading}</h1>
      <img src={officeImage} alt="Office space" width="400" />

      <h2>Available Office Spaces</h2>
      <ul>
        {offices.map((office, index) => (
          <li key={index}>
            <p><strong>Name:</strong> {office.name}</p>
            <p><strong>Address:</strong> {office.address}</p>
            <p><strong>Rent:</strong> <span style={rentStyle(office.rent)}>{office.rent}</span></p>
            <hr />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
