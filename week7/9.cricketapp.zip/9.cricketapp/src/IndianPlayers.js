import React from 'react';

const IndianPlayers = () => {
  const T20 = ["Rohit", "Virat", "Gill", "Sky", "Hardik"];
  const Ranji = ["Rahul", "Jadeja", "Ashwin", "Shami", "Bumrah", "Siraj"];

  // Merging arrays
  const allPlayers = [...T20, ...Ranji];

  // Destructuring into even and odd index players
  const oddPlayers = allPlayers.filter((_, index) => index % 2 !== 0);
  const evenPlayers = allPlayers.filter((_, index) => index % 2 === 0);

  return (
    <div>
      <h2>All Merged Players</h2>
      <ul>{allPlayers.map((player, i) => <li key={i}>{player}</li>)}</ul>

      <h2>Odd Team</h2>
      <ul>{oddPlayers.map((player, i) => <li key={i}>{player}</li>)}</ul>

      <h2>Even Team</h2>
      <ul>{evenPlayers.map((player, i) => <li key={i}>{player}</li>)}</ul>
    </div>
  );
};

export default IndianPlayers;
