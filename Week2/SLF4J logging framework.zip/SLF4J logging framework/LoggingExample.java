package com.example;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingExample {

    // Create a logger for this class
    private static final Logger logger = LoggerFactory.getLogger(LoggingExample.class);

    public static void main(String[] args) {

        // Log an error message
        logger.error(" This is an error message");

        // Log a warning message
        logger.warn("This is a warning message");

        // Optional: Just for fun, log an info too
        logger.info("This is an info message (might not show depending on default level)");
    }
}
