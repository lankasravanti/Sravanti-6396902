-- This procedure prints the multiplication table for a given number
CREATE OR REPLACE PROCEDURE print_table(num IN NUMBER) IS
BEGIN
    FOR i IN 1..10 LOOP
        DBMS_OUTPUT.PUT_LINE(num || ' x ' || i || ' = ' || (num * i));
    END LOOP;
END;
/

-- Call the procedure
BEGIN
    print_table(5);
END;
/
