--  calculating the square of a number and printing it
CREATE OR REPLACE PROCEDURE find_square(num IN NUMBER) IS
    square NUMBER;
BEGIN
    square := num * num;
    DBMS_OUTPUT.PUT_LINE('Square of ' || num || ' is ' || square);
END;
/

-- Call the procedure
BEGIN
    find_square(7);
END;
/

