-- This procedure prints a greeting based on the given hour
CREATE OR REPLACE PROCEDURE greet(hour IN NUMBER) IS
BEGIN
    IF hour < 12 THEN
        DBMS_OUTPUT.PUT_LINE('Good Morning!');
    ELSIF hour < 17 THEN
        DBMS_OUTPUT.PUT_LINE('Good Afternoon!');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Good Evening!');
    END IF;
END;
/

-- Call the procedure
BEGIN
    greet(15);
END;
/
