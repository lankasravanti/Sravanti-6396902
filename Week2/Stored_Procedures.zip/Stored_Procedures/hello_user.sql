-- procedure to print a personalized hello message
CREATE OR REPLACE PROCEDURE say_hello(name IN VARCHAR2) IS
BEGIN
    DBMS_OUTPUT.PUT_LINE('Hello, ' || name || '!');
END;
/

-- Call the procedure
BEGIN
    say_hello('Sravanti');
END;
/
