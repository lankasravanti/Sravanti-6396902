-- Enable DBMS Output
SET SERVEROUTPUT ON;

-- Drop tables if they exist
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE accounts CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE employees CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- Create Accounts Table
CREATE TABLE accounts (
    account_id     NUMBER PRIMARY KEY,
    customer_id    NUMBER,
    account_type   VARCHAR2(20),
    balance        NUMBER
);

--  Create Employees Table
CREATE TABLE employees (
    emp_id         NUMBER PRIMARY KEY,
    name           VARCHAR2(100),
    department     VARCHAR2(50),
    salary         NUMBER
);

-- Insert Sample Data into Accounts
INSERT INTO accounts VALUES (101, 1, 'Savings', 5000);
INSERT INTO accounts VALUES (102, 2, 'Savings', 10000);
INSERT INTO accounts VALUES (103, 3, 'Current', 8000);
INSERT INTO accounts VALUES (104, 4, 'Savings', 12000);

-- Insert Sample Data into Employees
INSERT INTO employees VALUES (1, 'John Doe', 'Sales', 50000);
INSERT INTO employees VALUES (2, 'Jane Smith', 'Sales', 55000);
INSERT INTO employees VALUES (3, 'Mike Brown', 'HR', 60000);

COMMIT;

-- Procedure: Process Monthly Interest
CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest AS
BEGIN
    DBMS_OUTPUT.PUT_LINE('Applying 1% interest to all savings accounts:');
    
    UPDATE accounts
    SET balance = balance + (balance * 0.01)
    WHERE LOWER(account_type) = 'savings';

    DBMS_OUTPUT.PUT_LINE('Interest applied successfully.');
END;
/

-- Call Procedure: ProcessMonthlyInterest
BEGIN
    ProcessMonthlyInterest;
END;
/

-- Procedure: Update Employee Bonus
CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    dept_name IN VARCHAR2,
    bonus_percent IN NUMBER
) AS
BEGIN
    DBMS_OUTPUT.PUT_LINE('Applying bonus to department: ' || dept_name);

    UPDATE employees
    SET salary = salary + (salary * bonus_percent / 100)
    WHERE department = dept_name;

    DBMS_OUTPUT.PUT_LINE('Bonus updated successfully.');
END;
/

-- Call Procedure: UpdateEmployeeBonus
BEGIN
    UpdateEmployeeBonus('Sales', 10);
END;
/

-- Procedure: Transfer Funds Between Accounts
CREATE OR REPLACE PROCEDURE TransferFunds (
    from_acc_id IN NUMBER,
    to_acc_id IN NUMBER,
    amount IN NUMBER
) AS
    from_balance NUMBER;
BEGIN
    -- Check sender balance
    SELECT balance INTO from_balance
    FROM accounts
    WHERE account_id = from_acc_id;

    IF from_balance < amount THEN
        DBMS_OUTPUT.PUT_LINE('Insufficient balance in source account.');
    ELSE
        -- Deduct from sender
        UPDATE accounts
        SET balance = balance - amount
        WHERE account_id = from_acc_id;

        -- Add to receiver
        UPDATE accounts
        SET balance = balance + amount
        WHERE account_id = to_acc_id;

        DBMS_OUTPUT.PUT_LINE('Transferred Rs. ' || amount ||
                             ' from Acc ID ' || from_acc_id || ' to Acc ID ' || to_acc_id);
    END IF;
END;
/

-- Call Procedure: TransferFunds
BEGIN
    TransferFunds(102, 103, 2000);
END;
/

-- View Final Results
SELECT * FROM accounts;
SELECT * FROM employees;
