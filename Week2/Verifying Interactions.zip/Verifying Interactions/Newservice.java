package com.example;

    import static org.mockito.Mockito.*;
//import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class Newservice {

    @Test
    public void testVerifyInteraction() {
        // 👇 Step 1: Create a mock of the external API
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);

        // 👇 Step 2: Create the service with the mock dependency
        MyService service = new MyService(mockApi);

        // 👇 Step 3: Call the method we want to test
        service.fetchData();

        // ✅ Step 4: Verify that getData() was called on the mock
        verify(mockApi).getData();
    }
}
