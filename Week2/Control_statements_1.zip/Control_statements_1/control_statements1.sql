-- Drop tables if they exist
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE loans CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE customers CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- Create customers table
CREATE TABLE customers (
    customer_id         NUMBER PRIMARY KEY,
    age                 NUMBER,
    balance             NUMBER,
    loan_interest_rate  NUMBER,
    IsVIP               VARCHAR2(5)
);
/

-- Create loans table
CREATE TABLE loans (
    loan_id         NUMBER PRIMARY KEY,
    customer_id     NUMBER,
    loan_due_date   DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
/

-- Insert sample data
INSERT INTO customers VALUES (101, 65, 15000, 7.5, 'FALSE');
INSERT INTO customers VALUES (102, 45, 8000, 8.0, 'FALSE');
INSERT INTO customers VALUES (103, 70, 12000, 6.5, 'FALSE');
INSERT INTO customers VALUES (104, 58, 4000, 9.0, 'FALSE');
INSERT INTO customers VALUES (105, 61, 10500, 8.2, 'FALSE');

INSERT INTO loans VALUES (1, 101, SYSDATE + 10);
INSERT INTO loans VALUES (2, 102, SYSDATE + 40);
INSERT INTO loans VALUES (3, 103, SYSDATE + 25);
INSERT INTO loans VALUES (4, 104, SYSDATE + 5);
INSERT INTO loans VALUES (5, 105, SYSDATE + 90);
COMMIT;
/

-- Scenario 1: Apply 1% discount for senior customers
BEGIN
    DBMS_OUTPUT.PUT_LINE('Scenario 1: Senior Discount');
    FOR customer IN (
        SELECT customer_id, age FROM customers
    ) LOOP
        IF customer.age > 60 THEN
            UPDATE customers
            SET loan_interest_rate = loan_interest_rate - 1
            WHERE customer_id = customer.customer_id;
            DBMS_OUTPUT.PUT_LINE('Discount applied to customer ID: ' || customer.customer_id);
        END IF;
    END LOOP;
END;
/

-- Scenario 2: Promote customers to VIP based on balance
BEGIN
    DBMS_OUTPUT.PUT_LINE('Scenario 2: VIP Promotion');
    FOR customer IN (
        SELECT customer_id, balance FROM customers
    ) LOOP
        IF customer.balance > 10000 THEN
            UPDATE customers
            SET IsVIP = 'TRUE'
            WHERE customer_id = customer.customer_id;
            DBMS_OUTPUT.PUT_LINE('Promoted to VIP: Customer ID ' || customer.customer_id);
        END IF;
    END LOOP;
END;
/

-- Scenario 3: Send loan due reminders
BEGIN
    DBMS_OUTPUT.PUT_LINE(' Scenario 3: Loan Due Reminders (Next 30 Days)');
    FOR loan IN (
        SELECT customer_id, loan_due_date FROM loans
        WHERE loan_due_date <= SYSDATE + 30
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Reminder: Customer ID ' || loan.customer_id ||
                             ' has a loan due on ' || TO_CHAR(loan.loan_due_date, 'DD-Mon-YYYY'));
    END LOOP;
END;
/
