package com.cognizant.account.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @GetMapping("/{number}")
    public AccountDTO getAccount(@PathVariable String number) {
        return new AccountDTO(number, "savings", 234_343L);
    }

    record AccountDTO(String number, String type, long balance) {}
}
