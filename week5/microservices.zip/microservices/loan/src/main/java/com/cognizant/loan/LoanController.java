package com.cognizant.loan;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/loans")
public class LoanController {

    @GetMapping("/{number}")
    public LoanDto getLoan(@PathVariable String number) {
        return new LoanDto(number, "car", 400000, 3258, 18);
    }

    record LoanDto(String number, String type, long loan, int emi, int tenure) {}
}
